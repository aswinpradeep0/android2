package com.capgemini.studentms;

/**
 * Created by geomathe on 11/20/2017.
 */

public class ObjectStudent
{

    int id;
    String firstname;
    String email;

    public ObjectStudent()
    {

    }

}
